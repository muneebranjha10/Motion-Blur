# One UI MotionGlass Lab — v0.1 (EXPERIMENTAL)

A source-code starter for researching Samsung One UI Home app launch/close animations on rooted devices with LSPosed. **This version does NOT implement directional/temporal motion blur.** Its optional mild duration adjustment is deliberately scoped to Samsung's launcher, and logs potential transition classes for further research.

## Why this architecture?

Samsung's system launcher participates in remote app-surface transitions. `SystemUI.apk` alone cannot tell us how the **home-screen** transition is assembled. The next step toward the reference video is to inspect the exact `com.sec.android.app.launcher` APK from your installed One UI build and target its transition methods. True motion blur needs per-frame temporal/surface rendering; slowing a standard fade or Gaussian background blur isn't the same.

## Current behavior

- An LSPosed APK (NOT a KernelSU-flashable ZIP).
- Scope: **Samsung One UI Home** (`com.sec.android.app.launcher`) ONLY.
- At launcher startup, logs whether common AOSP/Quickstep transition classes are present.
- Tries a **+10% duration** adjustment for ValueAnimator/AnimatorSet animations set up by likely launcher-transition call stacks, if such methods run. Other animations and packages are left alone as far as the hook filters can determine.
- If hooks fail, logs and uses stock behavior. Class names/method availability may vary with One UI versions.
- No SystemUI replacement, boot scripts, native libraries, or system settings writes.

## Build from GitHub on your phone

1. Create a new GitHub repository in your browser. Upload **the extracted files and folders**, not the ZIP as one file. GitHub's web upload does not unpack ZIPs. A phone file-manager+Termux/Git can push the folder tree if web upload is cumbersome.
2. Open the repository's **Actions** tab and select **Build MotionGlass Lab** → **Run workflow** (or push a commit to start it).
3. After a successful run, open the run and download the artifact named `motionglass-lab-debug-apk` from the **Artifacts** section. Extract it: the file inside is `app-debug.apk`.
4. Install `app-debug.apk`. This APK is an **LSPosed module**. In LSPosed, enable `MotionGlass Lab`, scope it **only to One UI Home**, then restart the launcher by rebooting the phone. (Don't select Android Framework/SystemUI.)
5. Test app opening/closing. In LSPosed logs, search for `MotionGlassLab:`. If there is no visible difference, that's an expected possible result: Samsung may use other transition paths.

You may get a Play Protect warning for a personal debug APK; inspect the source yourself and install only if you trust it. The debug build is signed with a development key by GitHub Actions, **not** a production signing identity.

## To disable/recover

In LSPosed Manager, disable this module for One UI Home and reboot. If launcher becomes unresponsive, use your root module framework's safe mode / disable LSPosed to recover, then uninstall the APK. Keep a backup. Avoid flashing random `SystemUI.apk`/launcher APK files.

## How to help with a real motion-blur v0.2

Provide the **One UI Home APK from your exact installed build** (package `com.sec.android.app.launcher`), plus LSPosed `MotionGlassLab:` logs and a short screen recording of the resulting animations. No private data should be bundled in the APK; obtain it from your own phone.

One UI 9 / Android 17 compatibility is **unverified** until tested on the actual device. This code uses old Xposed API entry points for LSPosed compatibility. KernelSU can host LSPosed, but the module you install is an APK, not a KernelSU ZIP.

## Implementation notes

App transitions controlled by SurfaceControl / Launcher remote animations cannot generally be replaced by a global Activity override hook. This prototype does not pretend otherwise. To implement temporal directional blur, further R&D is needed around Samsung's exact transition controller and surface composition.

Sources: AOSP synchronized app transitions documentation; LSPosed Module Scope wiki; AOSP QuickstepTransitionManager.
