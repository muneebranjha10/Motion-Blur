package de.robv.android.xposed;

/** Build-only signature. Not packaged in the app APK. */
public abstract class XC_MethodHook {
    protected void beforeHookedMethod(MethodHookParam param) throws Throwable { }
    protected void afterHookedMethod(MethodHookParam param) throws Throwable { }
    public static final class MethodHookParam {
        public Object thisObject;
        public Object[] args;
    }
    public final class Unhook { }
}
