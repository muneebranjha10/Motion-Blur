package dev.motionglass.lab;

import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Early Samsung One UI Home animation probe.
 * Only the One UI Home process is changed. This is NOT a motion-blur renderer.
 */
public final class MotionGlassHook implements IXposedHookLoadPackage {
    private static final String LAUNCHER = "com.sec.android.app.launcher";
    private static final String TAG = "MotionGlassLab: ";
    private static final boolean ENABLE_GENTLE_TIMING = true;
    private static final double DURATION_MULTIPLIER = 1.10;
    private static final AtomicInteger MOD_LOG_BUDGET = new AtomicInteger(12);

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam pkg) {
        if (!LAUNCHER.equals(pkg.packageName) || !LAUNCHER.equals(pkg.processName)) {
            return;
        }
        log("loaded in Samsung launcher process");
        probeClass(pkg.classLoader, "com.android.launcher3.QuickstepTransitionManager");
        probeClass(pkg.classLoader, "com.android.launcher3.QuickstepAppTransitionManagerImpl");
        probeClass(pkg.classLoader, "com.android.quickstep.AbsSwipeUpHandler");
        probeClass(pkg.classLoader, "com.android.launcher3.Launcher");
        if (!ENABLE_GENTLE_TIMING) {
            log("read-only diagnostics mode");
            return;
        }

        // These are framework classes but hooks are installed in this process,
        // as determined by the LSPosed package scope above.
        try {
            Set<XC_MethodHook.Unhook> installed = XposedBridge.hookAllMethods(
                    ValueAnimator.class, "setDuration", new TransitionDurationHook());
            log("ValueAnimator.setDuration hooks=" + installed.size());
        } catch (Throwable ex) {
            log("ValueAnimator hook skipped: " + ex);
        }
        try {
            Set<XC_MethodHook.Unhook> installed = XposedBridge.hookAllMethods(
                    AnimatorSet.class, "setDuration", new TransitionDurationHook());
            log("AnimatorSet.setDuration hooks=" + installed.size());
        } catch (Throwable ex) {
            log("AnimatorSet hook skipped: " + ex);
        }
    }

    private static void probeClass(ClassLoader loader, String name) {
        try {
            Class.forName(name, false, loader);
            log("FOUND " + name);
        } catch (ClassNotFoundException ignored) {
            log("absent " + name);
        } catch (Throwable ex) {
            log("cannot inspect " + name + ": " + ex.getClass().getSimpleName());
        }
    }

    private static final class TransitionDurationHook extends XC_MethodHook {
        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            try {
                if (param.args == null || param.args.length != 1 || !(param.args[0] instanceof Long)) {
                    return;
                }
                final long durationMs = (Long) param.args[0];
                // Avoid changing zero, very short, or long-running animations.
                if (durationMs < 140 || durationMs > 650) {
                    return;
                }
                if (!isLikelyLauncherTransition(Thread.currentThread().getStackTrace())) {
                    return;
                }
                final long adjusted = Math.min(715L, Math.round(durationMs * DURATION_MULTIPLIER));
                param.args[0] = adjusted;
                if (MOD_LOG_BUDGET.getAndDecrement() > 0) {
                    log("candidate transition timing " + durationMs + " -> " + adjusted + "ms");
                }
            } catch (Throwable ex) {
                // Safe failure: original method receives unmodified arguments.
                log("duration adjustment skipped: " + ex.getClass().getSimpleName());
            }
        }
    }

    private static boolean isLikelyLauncherTransition(StackTraceElement[] frames) {
        int limit = Math.min(frames.length, 24);
        for (int i = 3; i < limit; i++) {
            String name = frames[i].getClassName().toLowerCase(java.util.Locale.ROOT);
            // Narrow the change to identifiable transition-building call sites.
            if (name.contains("quickstep")
                    || name.contains("apptransition")
                    || name.contains("launcheranimation")
                    || name.contains("swipeuphandler")
                    || name.contains("transitionmanager")) {
                return true;
            }
        }
        return false;
    }

    private static void log(String message) {
        XposedBridge.log(TAG + message);
    }
}
